import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Switch, Pressable, Platform, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import * as LocalAuthentication from 'expo-local-authentication';
import { NoiseBackground } from '@/components/NoiseBackground';
import { GlassCard } from '@/components/GlassCard';
import { IPInfoCard } from '@/components/IPInfoCard';
import { SecuritySuitePanel } from '@/components/SecuritySuitePanel';
import { FingerprintShieldPanel } from '@/components/FingerprintShieldPanel';
import { useVpn } from '@/lib/vpn-context';
import { useFingerprintShield } from '@/lib/fingerprint-context';
import Colors from '@/constants/colors';

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const {
    protocol, setProtocol,
    killSwitch, setKillSwitch,
    autoConnect, setAutoConnect,
    doubleVpn, setDoubleVpn,
    isConnected,
    selectedServer,
    virtualIp,
    biometricLock, setBiometricLock,
    dnsLeakProtection, setDnsLeakProtection,
    adBlocker, setAdBlocker,
    stealthMode, setStealthMode,
  } = useVpn();
  const { summary } = useFingerprintShield();
  const [securityPanelVisible, setSecurityPanelVisible] = useState(false);
  const [fingerprintPanelVisible, setFingerprintPanelVisible] = useState(false);
  const topPadding = Platform.OS === 'web' ? 67 : insets.top;

  const handleBiometricToggle = useCallback(async (enable: boolean) => {
    if (Platform.OS === 'web') {
      Alert.alert('Not Available', 'Biometric authentication is only available on mobile devices.');
      return;
    }
    if (enable) {
      try {
        const hasHardware = await LocalAuthentication.hasHardwareAsync();
        if (!hasHardware) {
          Alert.alert('Not Available', 'Your device does not support biometric authentication.');
          return;
        }
        const isEnrolled = await LocalAuthentication.isEnrolledAsync();
        if (!isEnrolled) {
          Alert.alert('Not Set Up', 'Please set up biometric authentication in your device settings first.');
          return;
        }
        const result = await LocalAuthentication.authenticateAsync({
          promptMessage: 'Authenticate to enable biometric lock',
          fallbackLabel: 'Use passcode',
        });
        if (result.success) {
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          setBiometricLock(true);
        }
      } catch {
        Alert.alert('Error', 'Biometric authentication failed.');
      }
    } else {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      setBiometricLock(false);
    }
  }, [setBiometricLock]);

  const SettingRow = ({ icon, iconColor, iconLib, title, subtitle, children }: {
    icon: string;
    iconColor: string;
    iconLib?: 'ion' | 'mci';
    title: string;
    subtitle?: string;
    children: React.ReactNode;
  }) => (
    <View style={styles.settingRow}>
      <View style={[styles.settingIcon, { backgroundColor: `${iconColor}15` }]}>
        {iconLib === 'mci' ? (
          <MaterialCommunityIcons name={icon as any} size={18} color={iconColor} />
        ) : (
          <Ionicons name={icon as any} size={18} color={iconColor} />
        )}
      </View>
      <View style={styles.settingTextGroup}>
        <Text style={styles.settingTitle}>{title}</Text>
        {subtitle && <Text style={styles.settingSubtitle}>{subtitle}</Text>}
      </View>
      {children}
    </View>
  );

  return (
    <NoiseBackground>
      <ScrollView
        style={[styles.container, { paddingTop: topPadding }]}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={styles.title}>Settings</Text>
          <Text style={styles.subtitle}>Configure your VPN</Text>
        </View>

        <IPInfoCard
          isConnected={isConnected}
          virtualIp={virtualIp}
          serverCity={selectedServer?.city || ''}
          serverCountry={selectedServer?.country || ''}
        />

        <Text style={styles.sectionLabel}>SECURITY VAULT</Text>
        <Pressable
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            setSecurityPanelVisible(true);
          }}
        >
          <GlassCard style={styles.securitySuiteCard} intensity="medium" glowColor={Colors.dark.accent}>
            <View style={styles.suiteRow}>
              <View style={styles.suiteLeft}>
                <View style={styles.suiteIconWrap}>
                  <MaterialCommunityIcons name="shield-lock" size={22} color={Colors.dark.accent} />
                </View>
                <View style={styles.suiteTextGroup}>
                  <Text style={styles.suiteTitle}>Security Suite</Text>
                  <Text style={styles.suiteDesc}>Kill Switch, Double VPN, Protocol</Text>
                </View>
              </View>
              <View style={styles.suiteRight}>
                <View style={styles.suiteStatusPills}>
                  {killSwitch && (
                    <View style={[styles.miniPill, { borderColor: 'rgba(255,46,99,0.3)', backgroundColor: 'rgba(255,46,99,0.06)' }]}>
                      <View style={[styles.miniDot, { backgroundColor: Colors.dark.accentCoral }]} />
                      <Text style={[styles.miniPillText, { color: Colors.dark.accentCoral }]}>KS</Text>
                    </View>
                  )}
                  {doubleVpn && (
                    <View style={[styles.miniPill, { borderColor: 'rgba(195,0,255,0.3)', backgroundColor: 'rgba(195,0,255,0.06)' }]}>
                      <View style={[styles.miniDot, { backgroundColor: Colors.dark.accentPurple }]} />
                      <Text style={[styles.miniPillText, { color: Colors.dark.accentPurple }]}>2x</Text>
                    </View>
                  )}
                </View>
                <Ionicons name="chevron-forward" size={16} color={Colors.dark.textMuted} />
              </View>
            </View>
            <View style={styles.suiteProtocol}>
              <Ionicons name="shield-checkmark" size={12} color={Colors.dark.accent} />
              <Text style={styles.suiteProtocolText}>{protocol}</Text>
            </View>
          </GlassCard>
        </Pressable>

        <View style={{ height: 12 }} />

        <Pressable
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            setFingerprintPanelVisible(true);
          }}
        >
          <GlassCard style={styles.securitySuiteCard} intensity="medium" glowColor={Colors.dark.accentPurple}>
            <View style={styles.suiteRow}>
              <View style={styles.suiteLeft}>
                <View style={[styles.suiteIconWrap, { backgroundColor: 'rgba(195,0,255,0.08)', borderColor: 'rgba(195,0,255,0.15)' }]}>
                  <MaterialCommunityIcons name="fingerprint" size={22} color={Colors.dark.accentPurple} />
                </View>
                <View style={styles.suiteTextGroup}>
                  <Text style={styles.suiteTitle}>Fingerprint Shield</Text>
                  <Text style={styles.suiteDesc}>WebRTC, Timezone, Canvas, UA</Text>
                </View>
              </View>
              <View style={styles.suiteRight}>
                <View style={styles.suiteStatusPills}>
                  {summary.activeProtections > 0 && (
                    <View style={[styles.miniPill, { borderColor: 'rgba(195,0,255,0.3)', backgroundColor: 'rgba(195,0,255,0.06)' }]}>
                      <View style={[styles.miniDot, { backgroundColor: Colors.dark.accentPurple }]} />
                      <Text style={[styles.miniPillText, { color: Colors.dark.accentPurple }]}>{summary.activeProtections}/4</Text>
                    </View>
                  )}
                </View>
                <Ionicons name="chevron-forward" size={16} color={Colors.dark.textMuted} />
              </View>
            </View>
            <View style={styles.suiteProtocol}>
              <MaterialCommunityIcons name="shield-check" size={12} color={Colors.dark.accentPurple} />
              <Text style={[styles.suiteProtocolText, { color: Colors.dark.accentPurple }]}>
                {summary.protectionLevel.toUpperCase()}
              </Text>
            </View>
          </GlassCard>
        </Pressable>

        <Text style={styles.sectionLabel}>CONNECTION</Text>
        <GlassCard style={styles.settingsCard} intensity="low">
          <SettingRow icon="wifi-outline" iconColor={Colors.dark.accentPurple} title="Auto-Connect" subtitle="Connect on app launch">
            <Switch
              value={autoConnect}
              onValueChange={(v) => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setAutoConnect(v);
              }}
              trackColor={{ false: 'rgba(255,255,255,0.1)', true: 'rgba(195, 0, 255, 0.3)' }}
              thumbColor={autoConnect ? Colors.dark.accentPurple : '#666'}
            />
          </SettingRow>

          <View style={styles.divider} />

          <SettingRow icon="finger-print-outline" iconColor={Colors.dark.success} title="Biometric Lock" subtitle="Require Face ID / fingerprint">
            <Switch
              value={biometricLock}
              onValueChange={handleBiometricToggle}
              trackColor={{ false: 'rgba(255,255,255,0.1)', true: 'rgba(0, 230, 118, 0.3)' }}
              thumbColor={biometricLock ? Colors.dark.success : '#666'}
            />
          </SettingRow>

          <View style={styles.divider} />

          <SettingRow icon="eye-off" iconColor={Colors.dark.accentCoral} iconLib="mci" title="Stealth Mode" subtitle="Bypass deep packet inspection">
            <Switch
              value={stealthMode}
              onValueChange={(v) => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setStealthMode(v);
              }}
              trackColor={{ false: 'rgba(255,255,255,0.1)', true: 'rgba(255, 46, 99, 0.3)' }}
              thumbColor={stealthMode ? Colors.dark.accentCoral : '#666'}
            />
          </SettingRow>
        </GlassCard>

        <Text style={styles.sectionLabel}>PRIVACY</Text>
        <GlassCard style={styles.settingsCard} intensity="low">
          <SettingRow icon="eye-off-outline" iconColor={Colors.dark.accentCoral} title="DNS Leak Protection" subtitle="Prevent DNS queries outside tunnel">
            <Switch
              value={dnsLeakProtection}
              onValueChange={(v) => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setDnsLeakProtection(v);
              }}
              trackColor={{ false: 'rgba(255,255,255,0.1)', true: 'rgba(255, 46, 99, 0.3)' }}
              thumbColor={dnsLeakProtection ? Colors.dark.accentCoral : '#666'}
            />
          </SettingRow>

          <View style={styles.divider} />

          <SettingRow icon="analytics-outline" iconColor={Colors.dark.warning} title="Ad & Tracker Blocker" subtitle="Block ads, malware and trackers">
            <Switch
              value={adBlocker}
              onValueChange={(v) => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setAdBlocker(v);
              }}
              trackColor={{ false: 'rgba(255,255,255,0.1)', true: 'rgba(255,179,0,0.3)' }}
              thumbColor={adBlocker ? Colors.dark.warning : '#666'}
            />
          </SettingRow>

          <View style={styles.divider} />

          <SettingRow icon="document-text-outline" iconColor={Colors.dark.textSecondary} title="No-Log Policy" subtitle="Zero activity logging guaranteed">
            <View style={styles.verifiedBadge}>
              <Ionicons name="checkmark-circle" size={14} color={Colors.dark.success} />
              <Text style={styles.verifiedText}>Audited</Text>
            </View>
          </SettingRow>
        </GlassCard>

        <Text style={styles.sectionLabel}>ABOUT</Text>
        <GlassCard style={styles.settingsCard} intensity="low">
          <SettingRow icon="information-circle-outline" iconColor={Colors.dark.textSecondary} title="Version" subtitle="xVPN for mobile">
            <Text style={styles.versionText}>2.0.26</Text>
          </SettingRow>
        </GlassCard>

        <View style={styles.branding}>
          <Text style={styles.brandingLogo}>xVPN</Text>
          <Text style={styles.brandingText}>Deep Space Security</Text>
        </View>
      </ScrollView>

      <SecuritySuitePanel
        visible={securityPanelVisible}
        onClose={() => setSecurityPanelVisible(false)}
      />

      <FingerprintShieldPanel
        visible={fingerprintPanelVisible}
        onClose={() => setFingerprintPanelVisible(false)}
      />
    </NoiseBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 120,
  },
  header: {
    paddingHorizontal: 24,
    paddingTop: 12,
    paddingBottom: 16,
  },
  title: {
    fontFamily: 'Orbitron_700Bold',
    fontSize: 22,
    color: Colors.dark.text,
    letterSpacing: 2,
  },
  subtitle: {
    fontFamily: 'SpaceGrotesk_600SemiBold',
    fontSize: 13,
    color: Colors.dark.accent,
    marginTop: 4,
    textShadowColor: 'rgba(0,0,0,0.8)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 2,
  },
  sectionLabel: {
    fontFamily: 'Orbitron_700Bold',
    fontSize: 10,
    color: Colors.dark.accent,
    letterSpacing: 3,
    paddingHorizontal: 24,
    marginTop: 22,
    marginBottom: 10,
    textShadowColor: 'rgba(0,0,0,0.8)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 2,
  },
  securitySuiteCard: {
    marginHorizontal: 20,
    padding: 16,
    marginBottom: 2,
  },
  suiteRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  suiteLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  suiteIconWrap: {
    width: 42,
    height: 42,
    borderRadius: 14,
    backgroundColor: 'rgba(0,240,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(0,240,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  suiteTextGroup: {
    flex: 1,
  },
  suiteTitle: {
    fontFamily: 'SpaceGrotesk_600SemiBold',
    fontSize: 15,
    color: Colors.dark.text,
  },
  suiteDesc: {
    fontFamily: 'SpaceGrotesk_600SemiBold',
    fontSize: 11,
    color: Colors.dark.accent,
    marginTop: 2,
    letterSpacing: 0.3,
    textShadowColor: 'rgba(0,0,0,0.8)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 2,
  },
  suiteRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  suiteStatusPills: {
    flexDirection: 'row',
    gap: 4,
  },
  miniPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 6,
    borderWidth: 1,
  },
  miniDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
  },
  miniPillText: {
    fontFamily: 'Orbitron_700Bold',
    fontSize: 7,
    letterSpacing: 1,
  },
  suiteProtocol: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.04)',
  },
  suiteProtocolText: {
    fontFamily: 'Orbitron_700Bold',
    fontSize: 9,
    color: Colors.dark.accent,
    letterSpacing: 2,
  },
  settingsCard: {
    marginHorizontal: 20,
    padding: 4,
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    gap: 12,
  },
  settingIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  settingTextGroup: {
    flex: 1,
  },
  settingTitle: {
    fontFamily: 'SpaceGrotesk_600SemiBold',
    fontSize: 14,
    color: Colors.dark.text,
  },
  settingSubtitle: {
    fontFamily: 'SpaceGrotesk_600SemiBold',
    fontSize: 11,
    color: Colors.dark.accent,
    marginTop: 2,
    letterSpacing: 0.3,
    textShadowColor: 'rgba(0,0,0,0.8)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 2,
  },
  divider: {
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.04)',
    marginHorizontal: 14,
  },
  verifiedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(0, 230, 118, 0.1)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 10,
  },
  verifiedText: {
    fontFamily: 'SpaceGrotesk_400Regular',
    fontSize: 11,
    color: Colors.dark.success,
  },
  versionText: {
    fontFamily: 'Orbitron_700Bold',
    fontSize: 12,
    color: Colors.dark.textMuted,
  },
  branding: {
    alignItems: 'center',
    marginTop: 30,
    gap: 4,
  },
  brandingLogo: {
    fontFamily: 'Orbitron_700Bold',
    fontSize: 16,
    color: Colors.dark.accent,
    letterSpacing: 4,
    opacity: 0.4,
  },
  brandingText: {
    fontFamily: 'SpaceGrotesk_400Regular',
    fontSize: 11,
    color: Colors.dark.textMuted,
    opacity: 0.4,
  },
});
