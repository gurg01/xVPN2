import React, { useState, useMemo } from 'react';
import { View, Text, TextInput, StyleSheet, FlatList, Platform, Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { NoiseBackground } from '@/components/NoiseBackground';
import { ServerCard } from '@/components/ServerCard';
import { useVpn } from '@/lib/vpn-context';
import Colors from '@/constants/colors';
import Animated, { FadeIn, FadeOut, LinearTransition } from 'react-native-reanimated';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export default function ServersScreen() {
  const insets = useSafeAreaInsets();
  const { servers, selectedServer, selectServer, favoriteServerIds, toggleFavorite } = useVpn();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'favorites' | 'premium'>('all');
  const topPadding = Platform.OS === 'web' ? 67 : insets.top;

  const filteredServers = useMemo(() => {
    let list = servers;
    if (filter === 'favorites') list = list.filter(s => favoriteServerIds.includes(s.id));
    if (filter === 'premium') list = list.filter(s => s.premium);
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(s =>
        s.name.toLowerCase().includes(q) ||
        s.country.toLowerCase().includes(q) ||
        s.city.toLowerCase().includes(q)
      );
    }
    return list.sort((a, b) => a.ping - b.ping);
  }, [servers, filter, search, favoriteServerIds]);

  const FilterChip = ({ label, value, icon }: { label: string; value: typeof filter; icon?: any }) => {
    const isActive = filter === value;
    return (
      <AnimatedPressable
        layout={LinearTransition}
        style={[
          styles.chip, 
          isActive && styles.chipActive,
          isActive && styles.chipGlow
        ]}
        onPress={() => setFilter(value)}
      >
        {icon && <Ionicons name={icon} size={14} color={isActive ? Colors.dark.accent : Colors.dark.textSecondary} style={{ marginRight: 4 }} />}
        <Text style={[styles.chipText, isActive && styles.chipTextActive]}>{label}</Text>
      </AnimatedPressable>
    );
  };

  return (
    <NoiseBackground>
      <View style={[styles.container, { paddingTop: topPadding }]}>
        <View style={styles.header}>
          <Text style={styles.title}>Servers</Text>
          <Text style={styles.subtitle}>{servers.length} locations available</Text>
        </View>

        <View style={styles.searchContainer}>
          <Ionicons name="search" size={16} color={Colors.dark.textMuted} style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            value={search}
            onChangeText={setSearch}
            placeholder="Search locations..."
            placeholderTextColor={Colors.dark.textMuted}
          />
        </View>

        <View style={styles.filterRow}>
          <FilterChip label="All" value="all" />
          <FilterChip 
            label="Favorites" 
            value="favorites" 
            icon="heart" 
          />
          <FilterChip 
            label="Premium" 
            value="premium" 
            icon="star" 
          />
        </View>

        <Animated.FlatList
          itemLayoutAnimation={LinearTransition}
          data={filteredServers}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <Animated.View 
              entering={FadeIn.duration(300)} 
              exiting={FadeOut.duration(200)}
            >
              <ServerCard
                server={item}
                isSelected={selectedServer?.id === item.id}
                isFavorite={favoriteServerIds.includes(item.id)}
                onSelect={() => selectServer(item)}
                onToggleFavorite={() => toggleFavorite(item.id)}
              />
            </Animated.View>
          )}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <Animated.View entering={FadeIn} style={styles.emptyContainer}>
              <Ionicons name="globe-outline" size={48} color={Colors.dark.textMuted} />
              <Text style={styles.emptyText}>No servers found</Text>
            </Animated.View>
          }
        />
      </View>
    </NoiseBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 24,
    paddingTop: 12,
    paddingBottom: 8,
  },
  title: {
    fontFamily: 'Orbitron_700Bold',
    fontSize: 22,
    color: Colors.dark.text,
    letterSpacing: 2,
  },
  subtitle: {
    fontFamily: 'SpaceGrotesk_400Regular',
    fontSize: 13,
    color: Colors.dark.textMuted,
    marginTop: 4,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 20,
    marginVertical: 12,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.06)',
    paddingHorizontal: 14,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontFamily: 'SpaceGrotesk_400Regular',
    fontSize: 14,
    color: Colors.dark.text,
    paddingVertical: 12,
  },
  filterRow: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    gap: 8,
    marginBottom: 12,
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 7,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.06)',
  },
  chipActive: {
    backgroundColor: 'rgba(0, 240, 255, 0.1)',
    borderColor: 'rgba(0, 240, 255, 0.5)',
  },
  chipGlow: {
    shadowColor: Colors.dark.accent,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 5,
  },
  chipText: {
    fontFamily: 'SpaceGrotesk_400Regular',
    fontSize: 12,
    color: Colors.dark.textSecondary,
  },
  chipTextActive: {
    color: Colors.dark.accent,
    fontFamily: 'SpaceGrotesk_600SemiBold',
  },
  listContent: {
    paddingTop: 4,
    paddingBottom: 100,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 60,
    gap: 12,
  },
  emptyText: {
    fontFamily: 'SpaceGrotesk_400Regular',
    fontSize: 14,
    color: Colors.dark.textMuted,
  },
});
