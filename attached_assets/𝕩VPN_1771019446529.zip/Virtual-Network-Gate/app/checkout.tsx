import React from 'react';
import { View, Text, StyleSheet, Pressable, ScrollView, Platform } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { NoiseBackground } from '@/components/NoiseBackground';
import { GlassCard } from '@/components/GlassCard';
import { useVpn } from '@/lib/vpn-context';
import Colors from '@/constants/colors';

export default function CheckoutScreen() {
  const { serverId } = useLocalSearchParams();
  const router = useRouter();
  const { servers, setPremium } = useVpn();
  const server = servers.find(s => s.id === serverId);

  const handlePay = () => {
    setPremium(true);
    router.replace('/(tabs)/servers');
  };

  return (
    <NoiseBackground>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.header}>
          <Pressable onPress={() => router.back()} style={styles.backButton}>
            <Ionicons name="chevron-back" size={24} color={Colors.dark.text} />
          </Pressable>
          <Text style={styles.title}>Premium Access</Text>
        </View>

        <GlassCard style={styles.planCard} intensity="high">
          <View style={styles.serverBox}>
            <Ionicons name="diamond" size={24} color={Colors.dark.accentPurple} />
            <View>
              <Text style={styles.serverName}>{server?.name || 'Premium Server'}</Text>
              <Text style={styles.serverMeta}>Ultra-fast tunnel connection</Text>
            </View>
          </View>

          <View style={styles.plans}>
            <View style={[styles.plan, styles.planSelected]}>
              <View>
                <Text style={styles.planTitle}>Annual Plan</Text>
                <Text style={styles.planPrice}>$4.99/mo</Text>
              </View>
              <View style={styles.badge}>
                <Text style={styles.badgeText}>BEST VALUE</Text>
              </View>
            </View>
            <View style={styles.plan}>
              <View>
                <Text style={styles.planTitle}>Monthly Plan</Text>
                <Text style={styles.planPrice}>$9.99/mo</Text>
              </View>
            </View>
          </View>

          <Pressable style={styles.payButton} onPress={handlePay}>
            <Text style={styles.payText}>ACTIVATE PREMIUM</Text>
          </Pressable>
        </GlassCard>
      </ScrollView>
    </NoiseBackground>
  );
}

const styles = StyleSheet.create({
  container: { padding: 24, paddingTop: Platform.OS === 'web' ? 80 : 60 },
  header: { marginBottom: 32 },
  backButton: { marginBottom: 16, width: 40, height: 40, justifyContent: 'center', marginLeft: -8 },
  title: { fontFamily: 'Orbitron_700Bold', fontSize: 24, color: Colors.dark.text, letterSpacing: 2 },
  planCard: { padding: 24, gap: 24 },
  serverBox: { flexDirection: 'row', alignItems: 'center', gap: 16, backgroundColor: 'rgba(255,255,255,0.04)', padding: 16, borderRadius: 16 },
  serverName: { fontFamily: 'SpaceGrotesk_600SemiBold', fontSize: 18, color: Colors.dark.text },
  serverMeta: { fontFamily: 'SpaceGrotesk_400Regular', fontSize: 13, color: Colors.dark.textMuted },
  plans: { gap: 12 },
  plan: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.04)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)' },
  planSelected: { borderColor: Colors.dark.accentPurple, backgroundColor: 'rgba(195, 0, 255, 0.08)' },
  planTitle: { fontFamily: 'SpaceGrotesk_600SemiBold', fontSize: 16, color: Colors.dark.text },
  planPrice: { fontFamily: 'SpaceGrotesk_400Regular', fontSize: 14, color: Colors.dark.textMuted },
  badge: { backgroundColor: Colors.dark.accentPurple, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 },
  badgeText: { fontFamily: 'Orbitron_700Bold', fontSize: 8, color: '#FFF' },
  payButton: { backgroundColor: Colors.dark.accentPurple, padding: 18, borderRadius: 16, alignItems: 'center', shadowColor: Colors.dark.accentPurple, shadowOpacity: 0.5, shadowRadius: 10 },
  payText: { fontFamily: 'Orbitron_700Bold', fontSize: 14, color: '#FFF', letterSpacing: 2 },
});
