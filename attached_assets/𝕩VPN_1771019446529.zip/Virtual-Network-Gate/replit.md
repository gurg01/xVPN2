# replit.md

## Overview

xVPN is a mobile VPN client application built with React Native and Expo. It provides a polished, dark-themed UI for simulating VPN connections, server selection, connection statistics, and privacy/security settings. The app features a tab-based navigation with four main screens: Connect (dashboard), Servers, Stats, and Settings. It includes advanced UI features like fingerprint shield configuration, security suite panels, live telemetry, radar connection animations, and a world map visualization. The backend is a lightweight Express server with PostgreSQL for data persistence (currently only a users table).

**Important:** This is primarily a UI/UX demonstration app. The VPN functionality is simulated — there is no actual VPN tunnel being created. Connection states, speeds, and IP addresses are generated client-side.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend (Expo / React Native)

- **Framework:** Expo SDK 54 with React Native 0.81, using the new architecture
- **Routing:** expo-router v6 with file-based routing. Tab layout at `app/(tabs)/` with four tabs: index (Connect), servers, stats, settings. A standalone `checkout.tsx` route exists outside tabs for premium upgrade flow.
- **State Management:** React Context for VPN state (`lib/vpn-context.tsx`) and fingerprint shield state (`lib/fingerprint-context.tsx`). Both persist settings via `@react-native-async-storage/async-storage`.
- **Data Fetching:** TanStack React Query v5 with a custom query client (`lib/query-client.ts`) that constructs API URLs from `EXPO_PUBLIC_DOMAIN` environment variable.
- **Animations:** react-native-reanimated v4 is used extensively for smooth animations (pulsing dots, radar sweeps, button press effects, panel transitions).
- **UI Components:** Custom glass-morphism design system with `GlassCard`, `NoiseBackground` (animated gradient orbs), `HapticButton`, `PowerButton`, `WorldMap` (SVG-based), `StatRing`, `LiveTelemetry`, `RadarOverlay`, and various panel components.
- **Fonts:** Space Grotesk (regular/semibold) and Orbitron (bold) loaded via `@expo-google-fonts`.
- **Haptics:** expo-haptics used throughout for tactile feedback on button presses and toggles.
- **Biometrics:** expo-local-authentication for biometric lock toggle in settings (real native API, not simulated).
- **Color System:** Centralized in `constants/colors.ts` — dark theme with cyan (#00F0FF), purple (#C300FF), and coral (#FF2E63) accents.
- **Fingerprint Shield:** A privacy feature system (`lib/fingerprint-shield.ts`, `lib/fingerprint-runtime.ts`) that can mask WebRTC, spoof timezones, add canvas noise, and rotate user agents. These only work on web platform.

### Backend (Express)

- **Server:** Express v5 running on Node.js (`server/index.ts`)
- **Routes:** Registered in `server/routes.ts` — currently minimal, only creates an HTTP server with no custom API routes defined
- **Storage:** `server/storage.ts` implements `IStorage` interface with an in-memory implementation (`MemStorage`). Has basic user CRUD methods (getUser, getUserByUsername, createUser). Ready to be swapped for database-backed storage.
- **CORS:** Dynamic CORS configuration that allows Replit domains and localhost origins for Expo web development
- **Static serving:** In production, serves static web build files; in development, proxies to Expo's Metro bundler
- **Build pipeline:** `scripts/build.js` handles static web builds for deployment. Server is bundled with esbuild for production.

### Database

- **ORM:** Drizzle ORM configured for PostgreSQL (`drizzle.config.ts`)
- **Schema:** Defined in `shared/schema.ts` — currently only a `users` table with id (UUID), username, and password fields
- **Validation:** drizzle-zod generates Zod schemas from the Drizzle table definitions
- **Migration:** Uses `drizzle-kit push` for schema synchronization
- **Current state:** The database schema exists but isn't actively connected to the storage layer — `MemStorage` is used instead of a DB-backed implementation. The Drizzle config expects a `DATABASE_URL` environment variable.

### Key Design Decisions

1. **Simulated VPN:** All VPN connection logic is client-side state management. No actual networking tunnels are created. This keeps the app as a UI demonstration without requiring VPN infrastructure.

2. **Shared schema directory:** The `shared/` directory contains code used by both frontend and backend (Drizzle schema, Zod types), enabling type safety across the stack.

3. **Platform-aware code:** Many components check `Platform.OS` to handle web vs iOS vs Android differences (e.g., haptics disabled on web, glass effects use CSS backdrop-filter on web, biometrics only on mobile).

4. **Premium model:** The app has a simulated freemium model where some servers are marked premium. The checkout screen is a mock payment flow that just sets a premium flag in state.

## External Dependencies

### Core Runtime
- **Expo SDK 54** — managed React Native workflow
- **React 19.1** / **React Native 0.81.5**
- **Express 5** — backend HTTP server

### Database & ORM
- **PostgreSQL** — requires `DATABASE_URL` environment variable
- **Drizzle ORM** — type-safe SQL query builder
- **drizzle-zod** — schema validation generation
- **pg** — PostgreSQL client driver

### Key Libraries
- **expo-router** — file-based routing with typed routes
- **@tanstack/react-query** — server state management and caching
- **react-native-reanimated** — performant animations
- **react-native-gesture-handler** — gesture recognition
- **react-native-svg** — SVG rendering for charts, rings, maps
- **expo-haptics** — haptic feedback
- **expo-local-authentication** — biometric authentication (Face ID, Touch ID, fingerprint)
- **expo-linear-gradient** — gradient backgrounds
- **expo-blur** / **expo-glass-effect** — glass morphism effects
- **@react-native-async-storage/async-storage** — local persistence for settings
- **expo-secure-store** — secure credential storage (available but usage unclear from visible code)
- **http-proxy-middleware** — development proxy from Express to Metro bundler

### Fonts
- **@expo-google-fonts/space-grotesk** — primary UI font
- **@expo-google-fonts/orbitron** — accent/title font

### Build Tools
- **drizzle-kit** — database migration tooling
- **esbuild** — server bundling for production
- **tsx** — TypeScript execution for development server
- **patch-package** — applies patches to node_modules on install